CREATE TRIGGER BI_FILMS
BEFORE INSERT
  ON FILMS
FOR EACH ROW
  begin
  select FILMS_SEQ.nextval into :NEW.id from dual;
end;
/
