CREATE TRIGGER BI_CINEMAS
BEFORE INSERT
  ON CINEMAS
FOR EACH ROW
  begin
  select CINEMAS_SEQ.nextval into :NEW.id from dual;
end;
/
