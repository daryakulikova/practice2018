CREATE TRIGGER BI_CITIES
BEFORE INSERT
  ON CITIES
FOR EACH ROW
  begin
  select CITIES_SEQ.nextval into :NEW.id from dual;
end;
/
