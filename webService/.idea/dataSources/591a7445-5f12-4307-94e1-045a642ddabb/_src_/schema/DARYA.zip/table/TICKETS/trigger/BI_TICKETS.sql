CREATE TRIGGER BI_TICKETS
BEFORE INSERT
  ON TICKETS
FOR EACH ROW
  begin
  select TICKETS_SEQ.nextval into :NEW.id from dual;
end;
/
