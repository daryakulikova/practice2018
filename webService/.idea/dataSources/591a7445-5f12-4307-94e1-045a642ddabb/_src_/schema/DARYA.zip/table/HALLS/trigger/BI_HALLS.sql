CREATE TRIGGER BI_HALLS
BEFORE INSERT
  ON HALLS
FOR EACH ROW
  begin
  select HALLS_SEQ.nextval into :NEW.id from dual;
end;
/
